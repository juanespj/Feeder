/*******************************************************************************
* File Name: cycfg_peripherals.h
*
* Description:
* Peripheral Hardware Block configuration
* This file was automatically generated and should not be modified.
* Tools Package 2.2.1.3335
* mtb-pdl-cat1 2.1.0.5766
* personalities 3.0.0.0
* udd 3.0.0.727
*
********************************************************************************
* Copyright 2021 Cypress Semiconductor Corporation
* SPDX-License-Identifier: Apache-2.0
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
********************************************************************************/

#if !defined(CYCFG_PERIPHERALS_H)
#define CYCFG_PERIPHERALS_H

#include "cycfg_notices.h"
#if defined (CY_USING_HAL)
	#include "cyhal_hwmgr.h"
#endif //defined (CY_USING_HAL)
#include "cy_tcpwm_pwm.h"
#include "cy_sysclk.h"
#include "cycfg_routing.h"
#include "cy_tcpwm_counter.h"

#if defined(__cplusplus)
extern "C" {
#endif

#define CYBSP_BLE_ENABLED 1U
#define CY_BLE_CORE_CORTEX_M4 4U
#define CY_BLE_CORE_CORTEX_M0P 0U
#define CY_BLE_CORE_DUAL 255U
#ifndef CY_BLE_CORE
	#define CY_BLE_CORE 4U
#endif
#define CY_BLE_IRQ bless_interrupt_IRQn
#define motTrig_ENABLED 1U
#define motTrig_HW TCPWM0
#define motTrig_NUM 0UL
#define motTrig_MASK (1UL << 0)
#define motCount_ENABLED 1U
#define motCount_HW TCPWM0
#define motCount_NUM 1UL
#define motCount_MASK (1UL << 1)

#if defined (CY_USING_HAL)
	extern const cyhal_resource_inst_t CYBSP_BLE_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_tcpwm_pwm_config_t motTrig_config;
#if defined (CY_USING_HAL)
	extern const cyhal_resource_inst_t motTrig_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_tcpwm_counter_config_t motCount_config;
#if defined (CY_USING_HAL)
	extern const cyhal_resource_inst_t motCount_obj;
#endif //defined (CY_USING_HAL)

void init_cycfg_peripherals(void);

#if defined(__cplusplus)
}
#endif


#endif /* CYCFG_PERIPHERALS_H */
