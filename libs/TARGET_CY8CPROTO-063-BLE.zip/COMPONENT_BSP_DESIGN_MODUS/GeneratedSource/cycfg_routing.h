/*******************************************************************************
* File Name: cycfg_routing.h
*
* Description:
* Establishes all necessary connections between hardware elements.
* This file was automatically generated and should not be modified.
* Tools Package 2.2.1.3335
* mtb-pdl-cat1 2.1.0.5766
* personalities 3.0.0.0
* udd 3.0.0.727
*
********************************************************************************
* Copyright 2021 Cypress Semiconductor Corporation
* SPDX-License-Identifier: Apache-2.0
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
********************************************************************************/

#if !defined(CYCFG_ROUTING_H)
#define CYCFG_ROUTING_H

#if defined(__cplusplus)
extern "C" {
#endif

#include "cycfg_notices.h"
void init_cycfg_routing(void);
#define init_cycfg_connectivity() init_cycfg_routing()
#define ioss_0_port_0_pin_0_ANALOG P0_0_SRSS_WCO_IN
#define ioss_0_port_0_pin_1_ANALOG P0_1_SRSS_WCO_OUT
#define ioss_0_port_6_pin_6_HSIOM P6_6_CPUSS_SWJ_SWDIO_TMS
#define ioss_0_port_6_pin_7_HSIOM P6_7_CPUSS_SWJ_SWCLK_TCLK
#define ioss_0_port_10_pin_1_HSIOM P10_1_PERI_TR_IO_INPUT21
#define ioss_0_port_10_pin_4_HSIOM P10_4_TCPWM0_LINE0

#define MOT_ENCODER_digital_in_0_TRIGGER_IN_0 TRIG12_IN_PERI_TR_IO_INPUT21
#define MOT_ENCODER_digital_in_0_TRIGGER_IN_1 TRIG2_IN_TR_GROUP12_OUTPUT7
#define motCount_count_0_TRIGGER_OUT TRIG2_OUT_TCPWM0_TR_IN8
#define motCount_tr_overflow_0_TRIGGER_IN_0 TRIG11_IN_TCPWM0_TR_OVERFLOW1
#define motCount_tr_overflow_0_TRIGGER_IN_1 TRIG2_IN_TR_GROUP11_OUTPUT9
#define motTrig_stop_0_TRIGGER_OUT TRIG2_OUT_TCPWM0_TR_IN9

#define TCPWM0_CNT0_STOP_VALUE 0xb
#define TCPWM0_CNT1_COUNT_VALUE 0xa

#if defined(__cplusplus)
}
#endif


#endif /* CYCFG_ROUTING_H */
