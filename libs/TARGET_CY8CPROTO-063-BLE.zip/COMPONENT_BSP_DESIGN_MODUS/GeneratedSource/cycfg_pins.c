/*******************************************************************************
* File Name: cycfg_pins.c
*
* Description:
* Pin configuration
* This file was automatically generated and should not be modified.
* Tools Package 2.2.1.3335
* mtb-pdl-cat1 2.1.0.5766
* personalities 3.0.0.0
* udd 3.0.0.727
*
********************************************************************************
* Copyright 2021 Cypress Semiconductor Corporation
* SPDX-License-Identifier: Apache-2.0
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
********************************************************************************/

#include "cycfg_pins.h"

const cy_stc_gpio_pin_config_t WCO_IN_config = 
{
	.outVal = 1,
	.driveMode = CY_GPIO_DM_ANALOG,
	.hsiom = WCO_IN_HSIOM,
	.intEdge = CY_GPIO_INTR_DISABLE,
	.intMask = 0UL,
	.vtrip = CY_GPIO_VTRIP_CMOS,
	.slewRate = CY_GPIO_SLEW_FAST,
	.driveSel = CY_GPIO_DRIVE_1_2,
	.vregEn = 0UL,
	.ibufMode = 0UL,
	.vtripSel = 0UL,
	.vrefSel = 0UL,
	.vohSel = 0UL,
};
#if defined (CY_USING_HAL)
	const cyhal_resource_inst_t WCO_IN_obj = 
	{
		.type = CYHAL_RSC_GPIO,
		.block_num = WCO_IN_PORT_NUM,
		.channel_num = WCO_IN_PIN,
	};
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t WCO_OUT_config = 
{
	.outVal = 1,
	.driveMode = CY_GPIO_DM_ANALOG,
	.hsiom = WCO_OUT_HSIOM,
	.intEdge = CY_GPIO_INTR_DISABLE,
	.intMask = 0UL,
	.vtrip = CY_GPIO_VTRIP_CMOS,
	.slewRate = CY_GPIO_SLEW_FAST,
	.driveSel = CY_GPIO_DRIVE_1_2,
	.vregEn = 0UL,
	.ibufMode = 0UL,
	.vtripSel = 0UL,
	.vrefSel = 0UL,
	.vohSel = 0UL,
};
#if defined (CY_USING_HAL)
	const cyhal_resource_inst_t WCO_OUT_obj = 
	{
		.type = CYHAL_RSC_GPIO,
		.block_num = WCO_OUT_PORT_NUM,
		.channel_num = WCO_OUT_PIN,
	};
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t USR_BTN_config = 
{
	.outVal = 1,
	.driveMode = CY_GPIO_DM_PULLUP_IN_OFF,
	.hsiom = USR_BTN_HSIOM,
	.intEdge = CY_GPIO_INTR_DISABLE,
	.intMask = 0UL,
	.vtrip = CY_GPIO_VTRIP_CMOS,
	.slewRate = CY_GPIO_SLEW_FAST,
	.driveSel = CY_GPIO_DRIVE_1_2,
	.vregEn = 0UL,
	.ibufMode = 0UL,
	.vtripSel = 0UL,
	.vrefSel = 0UL,
	.vohSel = 0UL,
};
#if defined (CY_USING_HAL)
	const cyhal_resource_inst_t USR_BTN_obj = 
	{
		.type = CYHAL_RSC_GPIO,
		.block_num = USR_BTN_PORT_NUM,
		.channel_num = USR_BTN_PIN,
	};
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t MOT_ENCODER_config = 
{
	.outVal = 0,
	.driveMode = CY_GPIO_DM_HIGHZ,
	.hsiom = MOT_ENCODER_HSIOM,
	.intEdge = CY_GPIO_INTR_DISABLE,
	.intMask = 0UL,
	.vtrip = CY_GPIO_VTRIP_CMOS,
	.slewRate = CY_GPIO_SLEW_FAST,
	.driveSel = CY_GPIO_DRIVE_1_2,
	.vregEn = 0UL,
	.ibufMode = 0UL,
	.vtripSel = 0UL,
	.vrefSel = 0UL,
	.vohSel = 0UL,
};
#if defined (CY_USING_HAL)
	const cyhal_resource_inst_t MOT_ENCODER_obj = 
	{
		.type = CYHAL_RSC_GPIO,
		.block_num = MOT_ENCODER_PORT_NUM,
		.channel_num = MOT_ENCODER_PIN,
	};
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t BTN_config = 
{
	.outVal = 1,
	.driveMode = CY_GPIO_DM_PULLUP,
	.hsiom = BTN_HSIOM,
	.intEdge = CY_GPIO_INTR_DISABLE,
	.intMask = 0UL,
	.vtrip = CY_GPIO_VTRIP_CMOS,
	.slewRate = CY_GPIO_SLEW_FAST,
	.driveSel = CY_GPIO_DRIVE_1_2,
	.vregEn = 0UL,
	.ibufMode = 0UL,
	.vtripSel = 0UL,
	.vrefSel = 0UL,
	.vohSel = 0UL,
};
#if defined (CY_USING_HAL)
	const cyhal_resource_inst_t BTN_obj = 
	{
		.type = CYHAL_RSC_GPIO,
		.block_num = BTN_PORT_NUM,
		.channel_num = BTN_PIN,
	};
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t MOT_TRIG_config = 
{
	.outVal = 1,
	.driveMode = CY_GPIO_DM_STRONG_IN_OFF,
	.hsiom = MOT_TRIG_HSIOM,
	.intEdge = CY_GPIO_INTR_DISABLE,
	.intMask = 0UL,
	.vtrip = CY_GPIO_VTRIP_CMOS,
	.slewRate = CY_GPIO_SLEW_FAST,
	.driveSel = CY_GPIO_DRIVE_1_2,
	.vregEn = 0UL,
	.ibufMode = 0UL,
	.vtripSel = 0UL,
	.vrefSel = 0UL,
	.vohSel = 0UL,
};
#if defined (CY_USING_HAL)
	const cyhal_resource_inst_t MOT_TRIG_obj = 
	{
		.type = CYHAL_RSC_GPIO,
		.block_num = MOT_TRIG_PORT_NUM,
		.channel_num = MOT_TRIG_PIN,
	};
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t LED2_config = 
{
	.outVal = 0,
	.driveMode = CY_GPIO_DM_OD_DRIVESLOW_IN_OFF,
	.hsiom = LED2_HSIOM,
	.intEdge = CY_GPIO_INTR_DISABLE,
	.intMask = 0UL,
	.vtrip = CY_GPIO_VTRIP_CMOS,
	.slewRate = CY_GPIO_SLEW_FAST,
	.driveSel = CY_GPIO_DRIVE_1_2,
	.vregEn = 0UL,
	.ibufMode = 0UL,
	.vtripSel = 0UL,
	.vrefSel = 0UL,
	.vohSel = 0UL,
};
#if defined (CY_USING_HAL)
	const cyhal_resource_inst_t LED2_obj = 
	{
		.type = CYHAL_RSC_GPIO,
		.block_num = LED2_PORT_NUM,
		.channel_num = LED2_PIN,
	};
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t LED1_config = 
{
	.outVal = 0,
	.driveMode = CY_GPIO_DM_OD_DRIVESLOW_IN_OFF,
	.hsiom = LED1_HSIOM,
	.intEdge = CY_GPIO_INTR_DISABLE,
	.intMask = 0UL,
	.vtrip = CY_GPIO_VTRIP_CMOS,
	.slewRate = CY_GPIO_SLEW_FAST,
	.driveSel = CY_GPIO_DRIVE_1_2,
	.vregEn = 0UL,
	.ibufMode = 0UL,
	.vtripSel = 0UL,
	.vrefSel = 0UL,
	.vohSel = 0UL,
};
#if defined (CY_USING_HAL)
	const cyhal_resource_inst_t LED1_obj = 
	{
		.type = CYHAL_RSC_GPIO,
		.block_num = LED1_PORT_NUM,
		.channel_num = LED1_PIN,
	};
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t SWDIO_config = 
{
	.outVal = 1,
	.driveMode = CY_GPIO_DM_PULLUP,
	.hsiom = SWDIO_HSIOM,
	.intEdge = CY_GPIO_INTR_DISABLE,
	.intMask = 0UL,
	.vtrip = CY_GPIO_VTRIP_CMOS,
	.slewRate = CY_GPIO_SLEW_FAST,
	.driveSel = CY_GPIO_DRIVE_1_2,
	.vregEn = 0UL,
	.ibufMode = 0UL,
	.vtripSel = 0UL,
	.vrefSel = 0UL,
	.vohSel = 0UL,
};
#if defined (CY_USING_HAL)
	const cyhal_resource_inst_t SWDIO_obj = 
	{
		.type = CYHAL_RSC_GPIO,
		.block_num = SWDIO_PORT_NUM,
		.channel_num = SWDIO_PIN,
	};
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t SWCLK_config = 
{
	.outVal = 1,
	.driveMode = CY_GPIO_DM_PULLDOWN,
	.hsiom = SWCLK_HSIOM,
	.intEdge = CY_GPIO_INTR_DISABLE,
	.intMask = 0UL,
	.vtrip = CY_GPIO_VTRIP_CMOS,
	.slewRate = CY_GPIO_SLEW_FAST,
	.driveSel = CY_GPIO_DRIVE_1_2,
	.vregEn = 0UL,
	.ibufMode = 0UL,
	.vtripSel = 0UL,
	.vrefSel = 0UL,
	.vohSel = 0UL,
};
#if defined (CY_USING_HAL)
	const cyhal_resource_inst_t SWCLK_obj = 
	{
		.type = CYHAL_RSC_GPIO,
		.block_num = SWCLK_PORT_NUM,
		.channel_num = SWCLK_PIN,
	};
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t LED0_config = 
{
	.outVal = 0,
	.driveMode = CY_GPIO_DM_OD_DRIVESLOW_IN_OFF,
	.hsiom = LED0_HSIOM,
	.intEdge = CY_GPIO_INTR_DISABLE,
	.intMask = 0UL,
	.vtrip = CY_GPIO_VTRIP_CMOS,
	.slewRate = CY_GPIO_SLEW_FAST,
	.driveSel = CY_GPIO_DRIVE_1_2,
	.vregEn = 0UL,
	.ibufMode = 0UL,
	.vtripSel = 0UL,
	.vrefSel = 0UL,
	.vohSel = 0UL,
};
#if defined (CY_USING_HAL)
	const cyhal_resource_inst_t LED0_obj = 
	{
		.type = CYHAL_RSC_GPIO,
		.block_num = LED0_PORT_NUM,
		.channel_num = LED0_PIN,
	};
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t ioss_0_port_9_pin_1_config = 
{
	.outVal = 1,
	.driveMode = CY_GPIO_DM_HIGHZ,
	.hsiom = ioss_0_port_9_pin_1_HSIOM,
	.intEdge = CY_GPIO_INTR_DISABLE,
	.intMask = 0UL,
	.vtrip = CY_GPIO_VTRIP_CMOS,
	.slewRate = CY_GPIO_SLEW_FAST,
	.driveSel = CY_GPIO_DRIVE_1_2,
	.vregEn = 0UL,
	.ibufMode = 0UL,
	.vtripSel = 0UL,
	.vrefSel = 0UL,
	.vohSel = 0UL,
};
#if defined (CY_USING_HAL)
	const cyhal_resource_inst_t ioss_0_port_9_pin_1_obj = 
	{
		.type = CYHAL_RSC_GPIO,
		.block_num = ioss_0_port_9_pin_1_PORT_NUM,
		.channel_num = ioss_0_port_9_pin_1_PIN,
	};
#endif //defined (CY_USING_HAL)


void init_cycfg_pins(void)
{
	Cy_GPIO_Pin_Init(WCO_IN_PORT, WCO_IN_PIN, &WCO_IN_config);
#if defined (CY_USING_HAL)
	cyhal_hwmgr_reserve(&WCO_IN_obj);
#endif //defined (CY_USING_HAL)

	Cy_GPIO_Pin_Init(WCO_OUT_PORT, WCO_OUT_PIN, &WCO_OUT_config);
#if defined (CY_USING_HAL)
	cyhal_hwmgr_reserve(&WCO_OUT_obj);
#endif //defined (CY_USING_HAL)

	Cy_GPIO_Pin_Init(USR_BTN_PORT, USR_BTN_PIN, &USR_BTN_config);
#if defined (CY_USING_HAL)
	cyhal_hwmgr_reserve(&USR_BTN_obj);
#endif //defined (CY_USING_HAL)

	Cy_GPIO_Pin_Init(MOT_ENCODER_PORT, MOT_ENCODER_PIN, &MOT_ENCODER_config);
#if defined (CY_USING_HAL)
	cyhal_hwmgr_reserve(&MOT_ENCODER_obj);
#endif //defined (CY_USING_HAL)

	Cy_GPIO_Pin_Init(BTN_PORT, BTN_PIN, &BTN_config);
#if defined (CY_USING_HAL)
	cyhal_hwmgr_reserve(&BTN_obj);
#endif //defined (CY_USING_HAL)

	Cy_GPIO_Pin_Init(MOT_TRIG_PORT, MOT_TRIG_PIN, &MOT_TRIG_config);
#if defined (CY_USING_HAL)
	cyhal_hwmgr_reserve(&MOT_TRIG_obj);
#endif //defined (CY_USING_HAL)

	Cy_GPIO_Pin_Init(LED2_PORT, LED2_PIN, &LED2_config);
#if defined (CY_USING_HAL)
	cyhal_hwmgr_reserve(&LED2_obj);
#endif //defined (CY_USING_HAL)

	Cy_GPIO_Pin_Init(LED1_PORT, LED1_PIN, &LED1_config);
#if defined (CY_USING_HAL)
	cyhal_hwmgr_reserve(&LED1_obj);
#endif //defined (CY_USING_HAL)

	Cy_GPIO_Pin_Init(SWDIO_PORT, SWDIO_PIN, &SWDIO_config);
#if defined (CY_USING_HAL)
	cyhal_hwmgr_reserve(&SWDIO_obj);
#endif //defined (CY_USING_HAL)

	Cy_GPIO_Pin_Init(SWCLK_PORT, SWCLK_PIN, &SWCLK_config);
#if defined (CY_USING_HAL)
	cyhal_hwmgr_reserve(&SWCLK_obj);
#endif //defined (CY_USING_HAL)

	Cy_GPIO_Pin_Init(LED0_PORT, LED0_PIN, &LED0_config);
#if defined (CY_USING_HAL)
	cyhal_hwmgr_reserve(&LED0_obj);
#endif //defined (CY_USING_HAL)

	Cy_GPIO_Pin_Init(ioss_0_port_9_pin_1_PORT, ioss_0_port_9_pin_1_PIN, &ioss_0_port_9_pin_1_config);
#if defined (CY_USING_HAL)
	cyhal_hwmgr_reserve(&ioss_0_port_9_pin_1_obj);
#endif //defined (CY_USING_HAL)
}
