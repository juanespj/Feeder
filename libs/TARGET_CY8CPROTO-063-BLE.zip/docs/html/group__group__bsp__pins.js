var group__group__bsp__pins =
[
    [ "LED Pins", "group__group__bsp__pins__led.html", "group__group__bsp__pins__led" ],
    [ "Button Pins", "group__group__bsp__pins__btn.html", "group__group__bsp__pins__btn" ],
    [ "Communication Pins", "group__group__bsp__pins__comm.html", "group__group__bsp__pins__comm" ],
    [ "Arduino Header Pins", "group__group__bsp__pins__arduino.html", null ],
    [ "J2 Header Pins", "group__group__bsp__pins__j2.html", null ],
    [ "J6 Header Pins", "group__group__bsp__pins__j6.html", null ],
    [ "Capsense", "group__group__bsp__pins__capsense.html", null ],
    [ "WCO", "group__group__bsp__pins__wco.html", null ]
];