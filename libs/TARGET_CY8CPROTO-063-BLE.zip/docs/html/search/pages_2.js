var searchData=
[
  ['peripheral_20default_20bsp_20settings',['Peripheral Default BSP Settings',['../md_bsp_boards_psoc6_CY8CPROTO-063-BLE_bsp_settings.html',1,'']]]
];
