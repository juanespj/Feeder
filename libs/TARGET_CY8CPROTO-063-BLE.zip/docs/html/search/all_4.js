var searchData=
[
  ['j2_20header_20pins',['J2 Header Pins',['../group__group__bsp__pins__j2.html',1,'']]],
  ['j6_20header_20pins',['J6 Header Pins',['../group__group__bsp__pins__j6.html',1,'']]]
];
