var modules =
[
    [ "Macros", "group__group__bsp__macros.html", "group__group__bsp__macros" ],
    [ "Functions", "group__group__bsp__functions.html", "group__group__bsp__functions" ],
    [ "Pin States", "group__group__bsp__pin__state.html", "group__group__bsp__pin__state" ],
    [ "Pin Mappings", "group__group__bsp__pins.html", "group__group__bsp__pins" ]
];